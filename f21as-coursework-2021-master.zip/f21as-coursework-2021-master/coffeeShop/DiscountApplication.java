package coffeeShop;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

public class DiscountApplication {

	private static ArrayList<Discount> discounts;

	/** 
	 * Create a static list of discounts from a file.
	 * This method should be called one time by the Manager at its start.
	 * <p>
	 * The syntax of a discount in the file should be:
	 * "discount_type, number_of_categories_in_the_condition, category_1, ..., category_n, price or percentage"
	 * 
	 * @param file	the path to the file where discounts are defined ("discounts.csv" by default).
	 */
	public static void createDiscountList(String file) {

		discounts = new ArrayList<Discount>();
		List<String> fileLines = new ArrayList<String>();

		try {
			fileLines = Files.readAllLines(Paths.get(file));
		} catch (IOException e) {
			System.out.println("Unable to read the file " + file + ".");
			return;
		}

		String[] splitter;
		int len, percentage;
		float price;
		ArrayList<ItemCategory> condition = new ArrayList<ItemCategory>();

		for (String line : fileLines) {
			line = line.replaceAll(" ", "");
			splitter = line.split(",");

			try {
				len = Integer.parseInt(splitter[1]);
				condition.clear();

				for (int i=0;i<len;i++) {
					condition.add(ItemCategory.valueOf(splitter[2+i]));
				}

				switch(splitter[0]) {
				case "FreeItem":
					FreeItemDisc disc = new FreeItemDisc((ArrayList<ItemCategory>) condition.clone());
					discounts.add(disc);
					break;
				case "Price":
					price = Float.parseFloat(splitter[len+2]);
					PriceDisc priceDisc = new PriceDisc((ArrayList<ItemCategory>) condition.clone(), price);
					discounts.add(priceDisc);
					break;
				case "Percentage":
					percentage = Integer.parseInt(splitter[len+2]);
					PercentageDisc percDisc = new PercentageDisc((ArrayList<ItemCategory>) condition.clone(), percentage);
					discounts.add(percDisc); 
					break;
				}

			} catch(Exception e) {
				System.out.println("The line '" + line + "' is invalid.");
			}
		}
	}

	
	/** 
	 * This method apply the discounts to an order and return the final price of the order.
	 * It should be called in the Order class.
	 * <p>
	 * Each discount is applied as many times as possible.
	 * The result is therefore impacted by the order in which the discounts are defined.
	 * 
	 * @param initialPrice	the price of the order called in the second argument.
	 * @param order	an Order object.
	 */
	public static float applyDiscount(float initialPrice, Order order) {
		
		ArrayList<Item> orderedItems = (ArrayList<Item>) order.getList();
		ArrayList<Item> itemsTemp = (ArrayList<Item>) orderedItems.clone();
		ArrayList<Item> satisfyer = new ArrayList<Item>();
		ItemCategory cat;
		Item itemTMP;
		boolean conditionFlag, categoryFlag;
		int indDisc = 0, indCat = 0, indItem = 0;
		float voucher = 0;
		
		if (discounts == null) {
			System.out.println("No discount created");
			return initialPrice;
		}

		while (indDisc < discounts.size() && itemsTemp.size() > 0) {
			Discount disc = discounts.get(indDisc);
			conditionFlag = true;

			satisfyer.clear();

			indCat = 0;
			while (conditionFlag && indCat < disc.getCondition().size()) {

				cat = disc.getCondition().get(indCat);
				categoryFlag = false;
				indItem = 0;
				
				while (!categoryFlag && indItem < itemsTemp.size()) {
					itemTMP = itemsTemp.get(indItem);
					if (itemTMP.getCategory() == cat && !satisfyer.contains(itemTMP)) {
						categoryFlag = true;
						satisfyer.add(itemTMP);
					} else {
						indItem++;
						if (indItem == itemsTemp.size())
							conditionFlag = false;
					}
				}
				indCat++;
			}
			if (conditionFlag) {
				for (Item it : satisfyer) {itemsTemp.remove(it);}
				
				voucher += disc.getResult(satisfyer);
			} 
			else {indDisc++;}
		}
		return Float.parseFloat(String.format("%.02f", (initialPrice - voucher)).replace(",", "."));
	}


}
