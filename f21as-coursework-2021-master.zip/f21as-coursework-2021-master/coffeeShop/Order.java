package coffeeShop;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

public class Order implements Comparable<Order>
{
    private Timestamp time;
    private List<String> itemsID;
    private List<Item> items;
    private float discount;
    private float cost;

    public Order()
    {
        itemsID = new ArrayList<String>();
        items = new ArrayList<Item>();
        discount = 0;
        cost = 0;
    }

    public Order(Order other)
    {
        this.time = other.time;
        this.itemsID = new ArrayList<String>(other.itemsID);
        this.items = new ArrayList<Item>(other.items);
        this.discount = other.discount;
        this.cost = other.cost;
    }

    public boolean addItem(String itemID)
    {
        boolean itemExists = ItemFactory.getInstance().exists(itemID);

        if (itemExists) {
            itemsID.add(itemID);
        }
        return itemExists;
    }
    

    public boolean removeItem(String itemID)
    {
        return itemsID.remove(itemID);
    }

    public Timestamp getTime() { return time; }
    public void setTime(Timestamp time) { this.time = time; }

    public List<String> getItemsID() { return itemsID; }

    public float getDiscount() { return discount; }
    public void setDiscount(float discount) { this.discount = discount; }

    public float getCost() { return cost; }
    public void setCost(float cost) { this.cost = cost; }

    @Override
    public int compareTo(Order other)
    {
        return time.compareTo(other.time);
    }

    public String toString2()
    {
        return "[Order cost: " + cost + ", discount: " + discount + ", number of items: " + itemsID.size() + "]";
    }
    
    public List<Item> getList() { return items; }
    
    public boolean addItem(Item item)
    {
    	if (item == null) {
            return false;
    	}
    	items.add(item);
    	cost = cost + item.getCost();
        return true;
    }
    
    public boolean removeItem(Item item)
    {
    	if (item == null) {
            return false;
    	}
        boolean removed = items.remove(item);
        if (removed)
            cost = cost - item.getCost();
        return removed;
    }
    
    public void clear()
    {
    	items.clear();
    	itemsID.clear();
        discount = 0;
        cost = 0;
    }
    
    public String toString()
    {
        String ret = "[Order cost: " + cost + ", discount: " + discount + ", number of items: " + items.size() + "\n";
        
        for (int i = 0; i < items.size(); i++) {
            ret = ret + "\t" + items.get(i).toString() + "\n";
        }
        ret = ret + "]";
        return ret;
    }
}