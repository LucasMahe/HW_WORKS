package coffeeShop;

import java.util.ArrayList;
import java.util.List;

/** 
 * Discount that returns a percentage of the total price of the items of its condition.
 *
 */
public class PercentageDisc extends Discount {

	public PercentageDisc(ArrayList<ItemCategory> condition, int percentage) {
		
		this.setCondition(condition);
		
		this.setResult(((float) percentage)/100);
		
	}	
	
	public float getResult(ArrayList<Item> itemList) {
		float res=0;
		for (Item it : itemList) {res += it.getCost();}
		res *= this.getResult();
		return res;
	}
}
