package coffeeShop;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Collections;
import java.util.List;
import java.util.Map.Entry;
import java.util.PriorityQueue;
import java.util.stream.Collectors;

import java.io.FileWriter;  // Import the File class
import java.io.IOException;  // Import the IOException class to handle errors

/**
 * Facade which handles the different customers, orders, items
 * Used to Abstract the coffee shop management from the GUI class
 * Is a Singleton
 */
public class Manager {

    static Manager orderManager = null;
    //private PriorityQueue<CustomerOrder> orders;

    // holds the customers by ID
    HashMap<Integer, Customer> customers;
    

    private Manager()
    {
        customers = new HashMap<Integer, Customer>();
    }
    
    public static Manager getInstance()
    {
        if (orderManager == null)
            orderManager = new Manager();
        return orderManager;
    }

	/**
	 * create a new customer
	 */
    public int addCustomer()
    {
		Customer newCustomer = new Customer();
		int id = newCustomer.getId();
		
		customers.put(id, newCustomer);
		return (id);
    }

	/**
	 * create a new customer for a given id
	 */
    public int addCustomer(int id)
    {
    	Customer isAlreadyExist = customers.get(id);
    	
    	if (isAlreadyExist == null) {
    		Customer newCustomer = new Customer(id);
    		customers.put(id, newCustomer);
    	}
    	return (id);
    }


	/**
	 * @return the customers details as a String
	 */
	public String infoCustomers()
    {
    	String ret = "";
    	
    	for (Entry<Integer, Customer> me : customers.entrySet()) {
            ret = ret  + "Key: "+ me.getKey() + " & Value: " + me.getValue() + "\n";
        }
    	return (ret);
    }

	/**
	 * remove a customer by id
	 * @param id
	 * @return true if it works, false otherwise
	 */
	public boolean removeCustomer(int id)
    {
    	Customer res = (Customer)customers.remove(id);

		return res != null;
    }

	/**
	 * add an item to a customer order for a given customer ID
	 * @param item
	 * @param customerId
	 * @return the customer order updated
	 */
	public Order addItem(Item item, int customerId)
    {
    	Order ret = null;	
    	Customer cus = customers.get(customerId);
    
    	if (cus == null) {
    		return (null);
    	}
    	cus.addItemCurrentOrder(item);
    	return (cus.getCurrentOrder());
    }

	/**
	 * remove an item to a customer order for a given customer ID
	 * @param item
	 * @param customerId
	 * @return the customer order updated
	 */
    public Order removeItem(Item item, int customerId)
    {
    	Order ret = null;	
    	Customer cus = customers.get(customerId);
    
    	if (cus == null) {
    		return (null);
    	}
    	cus.removeItemCurrentOrder(item);
    	return (cus.getCurrentOrder());
    }

	/**
	 * Save the current order of a customer
	 * @param customerId
	 * @return true if it works, false otherwise
	 */
	public Boolean saveOrder(int customerId)
    {
    	Customer cus = customers.get(customerId);
        
    	if (cus == null) {
    		return (false);
    	}
    	cus.saveOrder();
    	return (true);
    }

	public void clearCurrentOrder(int customerId)
	{
		Customer cus = customers.get(customerId);

		if (cus == null)
			return;
		cus.clearCurrentOrder();
	}
    
    public Order getCustomerCurrentOrder(int customerId)
    {	
    	Customer cus = customers.get(customerId);

		return cus == null ? null : cus.getCurrentOrder();
    }

	/**
	 * @return the IDs of all the customers registered in the Manager
	 */
	public List<Integer> getCustomerIds()
    {
    	List<Integer> ret = new ArrayList<Integer>();
    	
    	for (Entry<Integer, Customer> me : customers.entrySet()) {
    		ret.add(me.getKey());
        }
    	return (ret);
    }
    
    public void generateReport()
    {
    	String ret = "=== Items Orders Total ===\n\n";
    	List<String> itemsIds =  ItemFactory.getInstance().getIDs();
    	
    	for (int i = 0; i < itemsIds.size(); i++) {
    		int countElement = 0;

    		ret = ret + itemsIds.get(i);
    		for (Entry<Integer, Customer> me : customers.entrySet()) {
    			Customer itCustomer = customers.get(me.getKey());
    			List<Item> listItemsCust = itCustomer.getAllItems();
    			
    			for (int j = 0; j < listItemsCust.size(); j++) {
    				if (listItemsCust.get(j).getId() == itemsIds.get(i)) {
    					countElement++;
    				}
    			}
            }
    		ret = ret + " : " + Integer.toString(countElement) + "\n";
    		
    	}
    	
    	ret = ret + "\n";
    	
    	float totalPrice = 0;
    	
    	for (Entry<Integer, Customer> me : customers.entrySet()) {
			Customer itCustomer = customers.get(me.getKey());
			float priceWithoutDiscount = 0;
			float priceWithDiscount = 0;
			List<Item> listItemsCust = itCustomer.getAllItems();
			
			List<Order> orders = itCustomer.getOrders();
			for (int i = 0; i < orders.size(); i++) {
				priceWithoutDiscount += orders.get(i).getCost();
				priceWithDiscount += orders.get(i).getDiscount();
				totalPrice += orders.get(i).getDiscount();
			}
			
			
			ret = ret + "Client : " + Integer.toString(me.getKey()) + "\n";
			ret = ret + "Price without discount : " + String.valueOf(priceWithoutDiscount) + "\n";
			ret = ret + "Price with discount : " + String.valueOf(priceWithDiscount) + "\n";
			ret = ret + "----\n";
			
			for (int i = 0; i < itemsIds.size(); i++) {
				int countElement = 0;

	    		ret = ret + "\t" + itemsIds.get(i) + " : ";
	    		for (int j = 0; j < listItemsCust.size(); j++) {
    				if (listItemsCust.get(j).getId() == itemsIds.get(i)) {
    					countElement++;
    				}
    			}
	    		ret = ret + Integer.toString(countElement) + "\n";
			}
			ret = ret + "\n";
			
    	}
    	ret = ret + "\nTotal: " + String.valueOf(totalPrice);
    	
    	
    	try {
    		FileWriter myWriter = new FileWriter("report.txt");
    		myWriter.write(ret);
    		myWriter.close();
    	} catch (IOException e) {
    		e.printStackTrace();
    	}
    }
}