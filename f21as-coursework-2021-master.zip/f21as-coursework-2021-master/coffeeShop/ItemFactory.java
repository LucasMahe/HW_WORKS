package coffeeShop;

import java.util.Map;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * design pattern Factory & Singleton
 * ItemFactory allows to register new items
 * and then create items from the ones registered
 * called it once per item in the file : registerItem(id, description, cost, category)
 * and then to create items for the orders : createItem(id)
 */
public class ItemFactory
{
	private static ItemFactory factory = null;
    private Map<String, Item> items;

    private ItemFactory() {
        items = new HashMap<String, Item>();
    }

    public static ItemFactory getInstance()
    {
    	if (factory == null)
    		factory = new ItemFactory();

        return factory;
    }

    /**
     * Register a new item if the parameters are valid (see Item constructor)
     * Throw if the cost is null or invalid
     * @param id
     * @param description
     * @param cost
     * @param category
     * @return
     * @throws InvalidCostException
     * @throws InvalidIDException
     */
    public boolean registerItem(String id, String description, Float cost, ItemCategory category) throws InvalidCostException, InvalidIDException
    {
        if (cost == null || cost < 0)
            throw cost == null ? new InvalidCostException() : new InvalidCostException(cost);

        if (items.containsKey(id)) {
            System.out.println("Item with ID '" + id + "' already exists.");
            return false;
        }
        items.put(id, new Item(id, description, cost, category));
        return true;
    }

    public Item createItem(String id) throws InvalidIDException
    {
    	if (items.containsKey(id))
			return new Item(items.get(id));
        throw new InvalidIDException(id);
    }

    public boolean exists(String id)
    {
        return items.containsKey(id);
    }

    /**
     * Get IDs of the registered Items
     * @return List<String> IDs
     */
    public List<String> getIDs()
    {
        List<String> ids = new ArrayList<String>();

        for (Map.Entry<String, Item> entry : items.entrySet())
            ids.add(entry.getKey());
        return ids;
    }
}