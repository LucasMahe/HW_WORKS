package coffeeShop;

import java.util.ArrayList;
import java.util.List;

/**
 * Hold a customer, its ID and a list of its orders
 */
public class Customer implements Comparable<Customer>
{
    static int currentID = 1;

    private Integer ID;
    private List<Order> orders;
    private Order currentOrder;

    /**
     * auto-increment the id of the new customer
     */
    public Customer()
    {
        ID = currentID++;
        orders = new ArrayList<Order>();
        currentOrder = new Order();
    }

    /**
     * Set explicitely the ID of the created customer
     * @param ID
     */
    public Customer(int ID)
    {
        this.ID = ID;
        
        if (ID >= currentID) {
        	currentID = ID + 1;
        }
        orders = new ArrayList<Order>();
        currentOrder = new Order();
    }

    public void saveOrder()
    {
        orders.add(new Order(currentOrder));
        currentOrder.clear();
    }
    
    
    public List<Order> getOrders()
    {
        return orders;
    }

    public int getId() { return ID; }

    @Override
    public int compareTo(Customer other)
    {
        return ID.compareTo(other.ID);
    }

    public String toString()
    {
        return "[Customer " + ID + ", number of orders: " + orders.size() + ", currentOrder: " + currentOrder.toString() + "]\n";
    }
    
    public Order getCurrentOrder()
    {
    	return currentOrder;
    }
    
    public boolean addItemCurrentOrder(Item item)
    {
        boolean added = currentOrder.addItem(item);

        // update discount only if the item has correctly be added
        if (added) {
            float discount = DiscountApplication.applyDiscount(currentOrder.getCost(), currentOrder);
            currentOrder.setDiscount(discount);
        }
        return added;
    }
    
    public boolean removeItemCurrentOrder(Item item)
    {
        boolean removed = currentOrder.removeItem(item);

        // update discount only if the item has correctly be removed
        if (removed) {
            float discount = DiscountApplication.applyDiscount(currentOrder.getCost(), currentOrder);
            currentOrder.setDiscount(discount);
        }
        return removed;
    }
    
    public void clearCurrentOrder()
    {
        currentOrder.clear();
    }

    /**
     * @return the items of all the customer orders
     */
    public List<Item> getAllItems()
    {
    	List<Item> ret = new ArrayList<Item>();
    	
    	for (int i = 0; i < orders.size(); i++) {
    		Order ord = orders.get(i);
    		List<Item> itemsInOrder = ord.getList();
    		for (int j = 0; j < itemsInOrder.size(); j++) {
    			ret.add(itemsInOrder.get(j));
    		}
    	}
    	return ret;
    }
}