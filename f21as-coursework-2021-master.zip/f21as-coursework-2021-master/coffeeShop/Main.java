package coffeeShop;

import java.util.List;
import java.io.BufferedReader; 
import java.io.IOException; 
import java.io.InputStreamReader;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.plaf.nimbus.NimbusLookAndFeel;

/**
 * Entry point of the application
 */
public class Main {
	public static void main(String [] args) throws IOException, InvalidIDException, UnsupportedLookAndFeelException
	{
		// parse the item files and register the items into the ItemFactory
		ItemFileParser.registerItemsFromFile();

		// create the possible discounts from the input file
		DiscountApplication.createDiscountList("discounts.csv");

		// parse the customer files and save the first orders into the Manager
		CustomerOrderFileParser.registerCustomerOrdersFromFile();

		// start the GUI
		UIManager.setLookAndFeel(new NimbusLookAndFeel());
		GUI frame = new GUI();
		frame.setVisible(true);
	}
}
