package coffeeShop;

import java.util.ArrayList;
import java.util.List;

/** 
 * Discount that returns the price of the cheapest item in its condition.
 *
 */
public class FreeItemDisc extends Discount {

	public FreeItemDisc(ArrayList<ItemCategory> condition) {
		this.setCondition(condition);
					
	}	
	
	public float getResult(ArrayList<Item> itemList) {
		if(itemList.size()<1) {
			return 0;
		}
		float res = itemList.get(0).getCost();
		for (Item it : itemList) {
			if (it.getCost() < res) {res = it.getCost();}
		}
		return res;
	}
}
