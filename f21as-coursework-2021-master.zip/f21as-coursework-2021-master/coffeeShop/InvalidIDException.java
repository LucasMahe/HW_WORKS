package coffeeShop;

/**
 * Is thrown when an Item ID is invalid (does not respect the format)
 *
 * id format: {ItemItemCategory}_{Number}
 * ItemCategory: Beverage, Food, Other
 * Number: any int > 0
 * example: Beverage_123
 *
 */
public class InvalidIDException extends Exception
{
    InvalidIDException(String id) {
        super("The ID '" + id + "' is invalid. It does not match {Category}_{Number}");
    }

    InvalidIDException(String id, ItemCategory category) {
        super("Error with the ID '" + id + "'. It should match the category " + category.name());
    }

    InvalidIDException(String id, String message) { super("The ID '" + id + "' is invalid. " + message); }
}