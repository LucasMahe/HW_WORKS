package coffeeShop;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

public class ItemFileParser
{
    static String fileName = "items.csv";

    /**
     * register a line of the file
     * Several messages are written in the console if the line is invalid
     * @param line
     * @return
     */
    public static boolean registerItemFromLine(String line)
    {
        String[] elements = line.split(",");
        if (elements.length != 4) {
            System.out.println("the line '" + line + "' is invalid. It must contain 4 parameters: ID,description,cost,category.");
            return false;
        }

        // check the cost
        Float cost;
        try {
            cost = Float.parseFloat(elements[2].trim());
        } catch (Exception ex) {
            System.out.println("the line '" + line + "' is invalid. The cost must be a positive number.");
            return false;
        }

        // check the category
        ItemCategory category = null;
        try {
            category = ItemCategory.valueOf(elements[3].trim());
        } catch (Exception ex) {
            System.out.println("the line '" + line + "' is invalid. The category must be Food, Beverage or Other");
            return false;
        }

        // register the item into the factory
        try {
            ItemFactory.getInstance().registerItem(elements[0].trim(), elements[1].trim(), cost, category);
        } catch (Exception ex) {
            System.out.println("On line '" + line + "': " + ex.getMessage());
            return false;
        }
        return true;
    }

    /**
     * read the file and register each line
     * exit if cannot read it.
     */
    public static void registerItemsFromFile()
    {
        List<String> fileLines = new ArrayList<String>();
		try {
			fileLines = Files.readAllLines(Paths.get(fileName));
		} catch (IOException e) {
			System.out.println("Unable to read the file " + fileName + ".");
			System.exit(0);
		}
        for (String line : fileLines)
            registerItemFromLine(line);
    }
}