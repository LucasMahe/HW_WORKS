package coffeeShop;

import java.util.ArrayList;

public abstract class Discount {

	private ArrayList<ItemCategory> condition;
	
	private float result;
	
	
	public ArrayList<ItemCategory> getCondition() {
		return (ArrayList<ItemCategory>) condition.clone() ;
	}
	
	
	public float getResult() {
		return result;
	}


	public void setCondition(ArrayList<ItemCategory> condition) {
		this.condition = condition;
	}


	public void setResult(float result) {
		this.result = result;
	}
	
	public abstract float getResult(ArrayList<Item> itemList);
	
	
	
}
