package coffeeShop;

/**
 * Is thrown when the cost for an item is invalid (null or negative)
 */
public class InvalidCostException extends Exception
{
    InvalidCostException(float cost) {
        super("The cost " + String.valueOf(cost) + " is invalid. It must be a positive number");
    }

    InvalidCostException() {
        super("The cost is empty. It must be a positive number");
    }
}