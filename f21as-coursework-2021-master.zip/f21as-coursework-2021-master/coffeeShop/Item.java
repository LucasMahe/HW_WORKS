package coffeeShop;

public class Item
{

    private String id;
    private Float cost;
    private String name;
    private ItemCategory category;

    /**
     * id format: {ItemItemCategory}_{Number}
     * ItemCategory: Beverage, Food, Other
     * Number: any int > 0
     * example: Beverage_123
     */
    public Item(String id, String name, Float cost, ItemCategory category) throws InvalidIDException
    {
        // check that the ID is valid
        ItemCategory categoryID = null;
        String[] parsedID = id.split("_");

        // check the id and throw if its format is invalid
        if (parsedID.length != 2)
            throw new InvalidIDException(id);
        try {
            categoryID = ItemCategory.valueOf(parsedID[0]);
            int number = Integer.parseInt(parsedID[1]);
            if (number <= 0)
                throw new Exception();
        } catch (Exception e) {
            throw new InvalidIDException(id);
        }

        if (categoryID != category)
            throw new InvalidIDException(id, category);

        // assign the attributes if the id is valid
        this.id = id;
        this.cost = cost;
        this.name = name;
        this.category = category;
    }

    public Item(Item model)
    {
        id = model.id;
        cost = model.cost;
        name = model.name;
        category = model.category;
    }

    public String getId() { return id; }

    public Float getCost() { return cost; }
    public void setCost(Float cost) { this.cost = cost; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public ItemCategory getCategory() { return category; }
    public void setItemCategory(ItemCategory category) { this.category = category; }

    @Override
    public String toString()
    {
        return "[Item " + id + ", name: " + name + ", " + " cost: " + cost + ", category: " + category.name() + "]";
    }
}