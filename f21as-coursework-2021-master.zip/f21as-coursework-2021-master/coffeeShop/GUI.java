package coffeeShop;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;
import java.awt.FlowLayout;
import java.awt.Point;

import javax.swing.JSplitPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTree;
import javax.swing.ListSelectionModel;
import javax.swing.UIManager;
import javax.swing.BoxLayout;
import javax.swing.ComboBoxModel;
import javax.swing.DefaultComboBoxModel;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;

import java.awt.Component;
import java.awt.Dimension;

import javax.swing.border.BevelBorder;
import javax.swing.border.LineBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.plaf.nimbus.NimbusLookAndFeel;
import javax.swing.table.DefaultTableModel;



import java.awt.Color;
import java.awt.Toolkit;
import javax.swing.JMenuItem;
import java.awt.Choice;
import javax.swing.JTextPane;
import javax.swing.SwingConstants;
import java.awt.Scrollbar;
import javax.swing.JList;
import javax.swing.JPopupMenu;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.swing.JTextField;

public class GUI extends JFrame {

	private static final long serialVersionUID = 4443303248990993973L;
	private JTextField ClientName;
	private JList ClientsList;
	private DefaultListModel ClientsListModel = new DefaultListModel();
	private static final String AddString = "Add Client";
    private static final String RmvClientString = "Remove";
    private static final String SelectString = "Select";
    private static final String SelectString2 = "Select";
    private JButton RmvClientButton;
    private JButton SelectClientButton;
    private JComboBox itemChoice ;
    private JComboBox numberChoice ;
    private String[] quantityStrings;
    private static int NbitemOrder = 1 ;
    private static String ItemNameOrder = "Vodka";
    private JTextArea BillTextPane;
    private ArrayList<ArrayList<String>> Clients = new ArrayList<ArrayList<String>>();
    private int ChosenClientID;
    private int ClientID;
    private Item I;
    private ArrayList<Item> itemsArray = new ArrayList<Item>();
    private int ItemIndex;
    private int TotalCost;
    private JPopupMenu popupMenu = new JPopupMenu();
    private JButton OrderButton = new JButton();
    private JButton OrderButtonRight = new JButton();
    private JButton CancelRight = new JButton();
    
    
    
	ItemFactory x = ItemFactory.getInstance();
	Manager M= Manager.getInstance();
	Order O = new Order();
	DiscountApplication Discount = new DiscountApplication();
	
	
	
	
	   
    // --- GUI Build ---
    public GUI() {
        super( "Chicken Coffee" );
        setIconImage(Toolkit.getDefaultToolkit().getImage("chicken.png"));
        this.setSize(1000,600);
        this.setLocationRelativeTo( null );
        this.setDefaultCloseOperation( DISPOSE_ON_CLOSE );
       
        
        // --- we get the contentPane ---
        JPanel contentPane = (JPanel) getContentPane();


        // --- Left Panel - Client management ---
        JPanel ClientPanel = new JPanel();
        ClientPanel.setPreferredSize( new Dimension( 200, 0 ) ); 
        ClientPanel.setLayout(new BorderLayout(0, 0));
        JLabel lblNewLabel = new JLabel("Clients");
        ClientPanel.add(lblNewLabel, BorderLayout.NORTH);
        JPanel AddClientPanel = new JPanel();
        JButton AddClientButton = new JButton("New Client");
        SelectClientButton = new JButton(SelectString);
        SelectClientButton.setEnabled(false);
        RmvClientButton = new JButton(RmvClientString);
        RmvClientButton.setEnabled(false);
        ClientPanel.add(AddClientPanel, BorderLayout.SOUTH);
        AddClientPanel.add(AddClientButton);
        AddClientPanel.add(RmvClientButton);
        AddClientPanel.add(SelectClientButton);
        RmvClientButton.setActionCommand(RmvClientString);
        RmvClientButton.addActionListener(new RmvClientListener());
        ClientsListModel = new DefaultListModel();
        ClientsListModel.addElement("Pick a client below or add a new client");
//        ClientsListModel.addElement("Jeremy");
//        ClientsListModel.addElement("Florian");
//        ClientsListModel.addElement("Bastien");
//        ClientsListModel.addElement("Lucas");
        ClientsList= new JList(ClientsListModel); 
        ClientsList.setSelectionMode(ListSelectionModel.SINGLE_INTERVAL_SELECTION);
        ClientsList.setLayoutOrientation(JList.VERTICAL);
        ClientsList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        ClientsList.setSelectedIndex(0);
        ClientsList.setVisibleRowCount(-1);
        ClientsList.setSelectionBackground(Color.blue);
        JScrollPane ClientsListScroller = new JScrollPane(ClientsList);
        ClientsListScroller.setPreferredSize(new Dimension(250, 80));
        ClientPanel.add(ClientsListScroller,BorderLayout.WEST);
        PopupListener PopupListener = new PopupListener();
        AddClientButton.addActionListener(PopupListener);
        popupMenu.setLabel("Enter your New Client Name");
        ClientName = new JTextField();
        popupMenu.add(ClientName);
        ClientName.setColumns(10);
        JButton BtnNewClients = new JButton(AddString);
        popupMenu.add(BtnNewClients, BorderLayout.SOUTH);
        AddClientListener AddClientListener = new AddClientListener(BtnNewClients);
        BtnNewClients.setActionCommand(AddString);
        BtnNewClients.addActionListener(AddClientListener);
        BtnNewClients.setEnabled(false);
        ClientName.addActionListener(AddClientListener);
        ClientName.getDocument().addDocumentListener(AddClientListener);
        String name = ClientsListModel.getElementAt(
                              ClientsList.getSelectedIndex()).toString();
        SelectClientButton.setActionCommand(SelectString);
        SelectClientButton.addActionListener(new SelectListener());
        
        
        
        
        
        
        // --- Central Panel - List and prices of the items ---
        ImageIcon img = new ImageIcon("logo.jpg");
        JScrollPane MenuScrollPane = new JScrollPane( );
        JLabel Background = new JLabel("", img,JLabel.CENTER);
        JPanel MenuPanel = new JPanel();
        MenuPanel.add(Background);
        String [] ListMenuBar= {"Id", "Name","Cost", "Category"};
            JTable Menu = new JTable(new DefaultTableModel(ListMenuBar,0));

            List<String>IDS =x.getIDs();
            DefaultTableModel model = (DefaultTableModel) Menu.getModel();
            ArrayList<String> itemStrings = new ArrayList<String>();
            for (int i = 0 ; i < IDS.size() ;i++) {
            	try {
            		 I = x.createItem(IDS.get(i));
            		 itemsArray.add(I);
					model.addRow(new Object[] { I.getId(), I.getName(), I.getCost(), I.getCategory()});
					itemStrings.add(I.getName());
				} catch (InvalidIDException e) {
					e.printStackTrace();
				}	
            }  
            
        Menu.setRowSelectionAllowed(false);
        Menu.setBounds(30, 40, 200, 300); 
        Menu.setShowHorizontalLines(true);
        Menu.setShowVerticalLines(true);
       MenuPanel.add(new JScrollPane(Menu));
      
       
       
        
        // --- Bottom Panel - Item Selection ---
        
        String[] quantityStrings = {"1", "2", "3", "4", "5","6","7","8","9","10" };
        JComboBox<String> itemChoice = new JComboBox<String>();
        itemChoice.setModel(new DefaultComboBoxModel<String>(itemStrings.toArray(new String[0])));
        numberChoice = new JComboBox(quantityStrings);
        AddItemToOrderListener AddItemToOrderListener = new AddItemToOrderListener();
        AddNumberOfItemToOrderListener AddNumberOfItemToOrderListener = new AddNumberOfItemToOrderListener();
        AddChoiceToOrderListener AddChoiceToOrderListener = new AddChoiceToOrderListener();
        itemChoice.addActionListener(AddItemToOrderListener);
        numberChoice.addActionListener(AddNumberOfItemToOrderListener);
        OrderButton = new JButton(SelectString2);
        if (ChosenClientID <= 0) {
            OrderButton.setEnabled(false);
        }
        OrderButton.addActionListener(AddChoiceToOrderListener);
        JPanel itemPanel = new JPanel();
        itemPanel.add(OrderButton, BoxLayout.X_AXIS);
        itemPanel.add(numberChoice, BoxLayout.X_AXIS);
        itemPanel.add(itemChoice, BoxLayout.X_AXIS);
        
        
        
        // --- Right Panel - Bill  ---
        OrderButtonRight = new JButton("Order");
        CancelRight = new JButton ("Cancel");
        if (ChosenClientID <= 0) {
            OrderButtonRight.setEnabled(false);
            CancelRight.setEnabled(false);
        }
        
        OrderListener OrderListener = new OrderListener();
        OrderButtonRight.addActionListener(OrderListener);
        ClearOrderListener ClearOrderListener = new ClearOrderListener();
        CancelRight.addActionListener(ClearOrderListener);
        JScrollPane outlineScrollPane = new JScrollPane();
        JPanel rightbuttonsPanel = new JPanel();
        rightbuttonsPanel.add(CancelRight);
        rightbuttonsPanel.add(OrderButtonRight);
        BillTextPane = new JTextArea();
        BillTextPane.setEditable(false);
        BillTextPane.setPreferredSize( new Dimension( 220, 0 ) );
        outlineScrollPane.setViewportView(BillTextPane);
        JLabel BillLabel = new JLabel("-------------------------BILL-------------------------------");
        outlineScrollPane.setColumnHeaderView(BillLabel);
        
        
        // --- let's assemble everything with the JSplitPane ---
        
        JSplitPane BillSplitPane = new JSplitPane(
		JSplitPane.VERTICAL_SPLIT, outlineScrollPane, rightbuttonsPanel);
        
        
        
      	contentPane.add( BillSplitPane /*, BorderLayout.CENTER */ );
      	BillSplitPane.setResizeWeight( 0.98);
      	
        JSplitPane documentSplitPane = new JSplitPane(
                JSplitPane.HORIZONTAL_SPLIT, MenuPanel, BillSplitPane );
        documentSplitPane.setResizeWeight( 0.8 );
        
        JSplitPane rightSplitPane = new JSplitPane(
                JSplitPane.VERTICAL_SPLIT, documentSplitPane, itemPanel );
        itemPanel.setLayout(new BoxLayout(itemPanel, BoxLayout.X_AXIS));
        rightSplitPane.setResizeWeight( 0.95 );
        
        JSplitPane mainSplitPane = new JSplitPane(
                JSplitPane.HORIZONTAL_SPLIT, ClientPanel, rightSplitPane );
        
        JList list = new JList();
        ClientPanel.add(list);
        
        contentPane.add( mainSplitPane /*, BorderLayout.CENTER */ );  
        
        // -- Listener to Generate the Order report (in txt file) when the GUI closes --
        addWindowListener( new WindowAdapter()
        {
            public void windowClosing(WindowEvent e)
            {
            	M.generateReport();
                e.getWindow().dispose();
            }
        });
        

        

    }

//     -- Popup Listener to add new clients --
		class PopupListener implements ActionListener{
		public void actionPerformed(ActionEvent e) {
			showPopup(e);
			}
			
		}
	private void showPopup(ActionEvent e)
    {
        // Get the event source
        Component b=(Component)e.getSource();
        
        // Get the location of the point 'on the screen'
        Point p=b.getLocationOnScreen();
        
        // Show the JPopupMenu via program
        // this - represents current frame
        // 0,0 is the co ordinate where the popup is shown
        popupMenu.show(this,0,0);
        
        // Now set the location of the JPopupMenu
        // This location is relative to the screen
        popupMenu.setLocation(p.x,p.y+b.getHeight());
    }
		

	// --- Below are all the Listener Class that operate the buttons ---

	class AddNumberOfItemToOrderListener implements ActionListener{
		public void actionPerformed(ActionEvent e) {
			JComboBox nb = (JComboBox)e.getSource();
			String SNbitemOrder = (String)nb.getSelectedItem();
			NbitemOrder = Integer.parseInt(SNbitemOrder);
		}
	}
	class AddItemToOrderListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			JComboBox cb = (JComboBox)e.getSource();
			ItemNameOrder = (String)cb.getSelectedItem(); 
			ItemIndex =cb.getSelectedIndex();
		}	
	}
	
	class AddChoiceToOrderListener implements ActionListener{
		
		public void actionPerformed(ActionEvent e) {
			
			try {
				for (int i=0; i<NbitemOrder;i++) {
					if (ChosenClientID > 0) {
						BillTextPane.append(ItemNameOrder + (ItemNameOrder.length() > 12 ? "\t" : "\t\t") + "£" + itemsArray.get(ItemIndex).getCost() + "\n");
						TotalCost += itemsArray.get(ItemIndex).getCost();
						// the item needs to be recreated to be considered as different by the discounts
						Item newItem = ItemFactory.getInstance().createItem(itemsArray.get(ItemIndex).getId());
					    M.addItem(newItem, ChosenClientID);
//					    System.out.println(itemsArray.get(ItemIndex));
					}
					else {
						System.out.println("You forgot to select a Client !");
					}
				}
			}
			catch(Exception e1){
				System.out.println(e1);
			}
		}
		
	}
	
	
	class ClearOrderListener implements ActionListener{
		public void actionPerformed(ActionEvent e) {
			BillTextPane.setText("");
            M.clearCurrentOrder(ChosenClientID);
			TotalCost = 0;
		}
		
	}
	
	class OrderListener implements ActionListener{
		public void actionPerformed(ActionEvent e) {
			if (ChosenClientID > 0) {
			    O = M.getCustomerCurrentOrder(ChosenClientID);
				float FinalCost = O.getDiscount();
	//			System.out.println(M.getCustomerCurrentOrder(ChosenClientID));
				M.saveOrder(ChosenClientID);
	//			System.out.println(TotalCost);
	//			System.out.println(FinalCost);
				BillTextPane.setText("                  The total Cost of \n                     your order is \n                           "+"£" + FinalCost);
			}
			else {
				System.out.println("You forgot to select a client !");
			}
			
		}
	}
	
	
	class RmvClientListener implements ActionListener {
	    public void actionPerformed(ActionEvent e) {
	        int index = ClientsList.getSelectedIndex();
	        ClientsListModel.remove(index);
	        M.removeCustomer(index);
	        Clients.remove(index-1);
	        ClientsList.setSelectionBackground(Color.blue);
	        ClientsList.setSelectedIndex(index-1);
	        BillTextPane.setText("");
            M.clearCurrentOrder(ChosenClientID);
			TotalCost = 0;
	        
	        int size = ClientsListModel.getSize();

	        if (size == 1) { //Nobody's left, disable removing.
	        	RmvClientButton.setEnabled(false);
	        	SelectClientButton.setEnabled(false);
	        	OrderButtonRight.setEnabled(false);
	        	OrderButton.setEnabled(false);
	        } else { //Select an index.
	            if (index == ClientsListModel.getSize()) {
	                //removed item in last position
	                index--;
	            }

	            ClientsList.setSelectedIndex(index);
	            ClientsList.ensureIndexIsVisible(index);
	            
	        }
	    }
	}
	
	
	class SelectListener implements ActionListener{
		public void actionPerformed(ActionEvent e) {
			int index = ClientsList.getSelectedIndex();
			String name = (String) ClientsListModel.get(index);
			ClientID = index;
//			System.out.println(ClientID);
//			System.out.println(Clients);
			ArrayList<String> list2 = new ArrayList<String>();
			list2 = Clients.get(index-1);
			String ChosenClient = list2.get(0);
			ChosenClientID = Integer.parseInt(ChosenClient);
			OrderButton.setEnabled(true);
			OrderButtonRight.setEnabled(true);
			CancelRight.setEnabled(true);
			BillTextPane.setText("");
            M.clearCurrentOrder(ChosenClientID);
			TotalCost = 0;
			ClientsList.setSelectionBackground(Color.red);
//			System.out.println(ChosenClientID);
		}
	}
	
	
	
    class AddClientListener implements ActionListener, DocumentListener {
        private boolean alreadyEnabled = false;
        private JButton button;

        public AddClientListener(JButton button) {
            this.button = button;
        }

        //Required by ActionListener.
        public void actionPerformed(ActionEvent e) {
            String name = ClientName.getText();           
            ClientID= M.addCustomer();
            String ClientIDStr = Integer.toString(ClientID);
            ArrayList<String> list1 = new ArrayList<String>();
            list1.add(ClientIDStr);
            list1.add(name);
            Clients.add(list1);
            //User didn't type in a unique name...
            if (name.equals("") || alreadyInList(name)) {
                Toolkit.getDefaultToolkit().beep();
                ClientName.requestFocusInWindow();
                ClientName.selectAll();
                return;
            }

            int index = ClientsList.getSelectedIndex(); //get selected index
            if (index == -1) { //no selection, so insert at beginning
                index = 0;
            } else {           //add after the selected item
                index++;
            }

            ClientsListModel.insertElementAt(ClientName.getText(), index);
            //If we just wanted to add to the end, we'd do this:
            //Reset the text field.
            ClientName.requestFocusInWindow();
            ClientName.setText("");

            //Select the new item and make it visible.
            ClientsList.setSelectedIndex(index);
            ClientsList.ensureIndexIsVisible(index);
            
            RmvClientButton.setEnabled(true);
            SelectClientButton.setEnabled(true);
            
        }

        //This method tests for string equality.
        protected boolean alreadyInList(String name) {
            return ClientsListModel.contains(name);
        }

        //Required by DocumentListener.
        public void insertUpdate(DocumentEvent e) {
            enableButton();
        }

        //Required by DocumentListener.
        public void removeUpdate(DocumentEvent e) {
            handleEmptyTextField(e);
        }

        //Required by DocumentListener.
        public void changedUpdate(DocumentEvent e) {
            if (!handleEmptyTextField(e)) {
                enableButton();
            }
        }

        private void enableButton() {
            if (!alreadyEnabled) {
                button.setEnabled(true);
            }
        }

        private boolean handleEmptyTextField(DocumentEvent e) {
            if (e.getDocument().getLength() <= 0) {
                button.setEnabled(false);
                alreadyEnabled = false;
                return true;
            }
            return false;
        }
    }
	 
}


