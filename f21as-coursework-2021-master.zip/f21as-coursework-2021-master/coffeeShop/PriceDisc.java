package coffeeShop;

import java.util.ArrayList;
import java.util.List;

/** 
 * Discount with a fix price in return.
 *
 */
public class PriceDisc extends Discount {

	public PriceDisc(ArrayList<ItemCategory> condition, float price) {
		
		this.setCondition(condition);
		
		this.setResult(price);
				
	}
	
	public float getResult(ArrayList<Item> itemList) {
		return this.getResult();
	}

}
