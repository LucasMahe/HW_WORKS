package coffeeShop;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

public class CustomerOrderFileParser
{
	public static String fileName = "customer-orders.csv";

    /**
     * register a line of the file
     * Several messages are written in the console if the line is invalid
     * @param line
     * @return
     */
    public static boolean registerCustomerOrderFromLine(String line)
    {
        String[] elements = line.split(",");
        // check the number of elements in the line
        if (elements.length != 3) {
            System.out.println("the line '" + line + "' is invalid. It must contain 3 parameters: timestamp,customer number,item ID.");
            return false;
        }

        // check the timestamp of the line
        Timestamp timestamp = null;
        try {
            timestamp = Timestamp.valueOf(elements[0].trim());
        } catch (Exception ex) {
            System.out.println("the line '" + line + "' is invalid. The first element must be a timestamp in the format yyyy-mm-dd hh:mm:ss");
            return false;
        }

        // check the customer number
        Integer number = null;
        try {
            number = Integer.valueOf(elements[1].trim());
            if (number <= 0)
                throw new Exception();
        } catch (Exception ex) {
            System.out.println("the line '" + line + "' is invalid. The customer number must be a positive integer.");
            return false;
        }

        // create the item and add it to the Manager
        try {
	        Manager manager = Manager.getInstance();
	        manager.addCustomer(number);
	        Item item = ItemFactory.getInstance().createItem(elements[2].trim());
	        manager.addItem(item, number);
        } catch (InvalidIDException e) {
            System.out.println("the line '" + line + "' is invalid. " + e.getMessage());
            return false;
        }

        return true;
    }

    /**
     * read the file and register each line
     * exit if cannot read it.
     */
    public static void registerCustomerOrdersFromFile()
    {
        List<String> fileLines = new ArrayList<String>();
        try {
            fileLines = Files.readAllLines(Paths.get(fileName));
        } catch (IOException e) {
            System.out.println("Unable to read the file " + fileName + ".");
            System.exit(0);
        }
        for (String line : fileLines)
            registerCustomerOrderFromLine(line);
    }
}