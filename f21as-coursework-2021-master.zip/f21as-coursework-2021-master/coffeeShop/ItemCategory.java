package coffeeShop;

public enum ItemCategory {
    Snack,
    Dish,
    Soft,
    Alcohol,
    Other,
}