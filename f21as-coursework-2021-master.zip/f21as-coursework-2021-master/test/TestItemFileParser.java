package test;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.Test;

import coffeeShop.ItemFileParser;
import coffeeShop.InvalidIDException;
import coffeeShop.ItemFactory;
import coffeeShop.ItemCategory;


class TestItemFileParser {
    @Test
    public void TestParseLine()
    {
        // invalid line parsing
        assertFalse(ItemFileParser.registerItemFromLine("invalid line"));
        assertFalse(ItemFileParser.registerItemFromLine("Soft_555, donut, 2"));
        assertFalse(ItemFileParser.registerItemFromLine("Soft_555, donut, 2, Soft, something"));
        assertFalse(ItemFileParser.registerItemFromLine("Soft_555, donut, 2, NOT A CATEGORY"));
        assertFalse(ItemFileParser.registerItemFromLine("Soft_555, donut, NOT A NUMBER, Soft"));
        assertFalse(ItemFileParser.registerItemFromLine("Soft_555, donut, -9, Soft"));
        assertFalse(ItemFileParser.registerItemFromLine("INVALID ID, donut, 3, Soft"));

        // valid line parsing
        assertTrue(ItemFileParser.registerItemFromLine("Soft_555, donut, 3, Soft"));
        try {
			assertNotNull(ItemFactory.getInstance().createItem("Soft_555"));
		} catch (InvalidIDException e) {
			fail();
		}
    }
}