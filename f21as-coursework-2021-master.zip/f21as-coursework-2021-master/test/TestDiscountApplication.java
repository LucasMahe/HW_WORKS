package test;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.math.BigDecimal;
import java.math.RoundingMode;

//import coffeeShop.CustomerOrder;
import coffeeShop.Discount;
import coffeeShop.InvalidIDException;
import coffeeShop.Item;
import coffeeShop.ItemFactory;
import coffeeShop.ItemFileParser;
import coffeeShop.ItemCategory;
import coffeeShop.Order;
import coffeeShop.PercentageDisc;

import org.junit.jupiter.api.Test;

import coffeeShop.DiscountApplication;
import coffeeShop.FreeItemDisc;

class TestDiscountApplication {

	static float decimalRoundValue(float value)
	{
		return (new BigDecimal(value).setScale(2, RoundingMode.HALF_UP)).floatValue();
	}

	@Test
	void testCreateDiscountList() {
		DiscountApplication.createDiscountList("discounts.csv");
	}
	
	@Test
	void testCreateDiscountList2() {
		DiscountApplication.createDiscountList("test");
		
	}

	
	@Test
	void testApplyDiscount() throws InvalidIDException {

		float price = 77;
		float expected_discount = (float) 71.3;

		DiscountApplication.createDiscountList("discounts.csv");
		ItemFileParser.registerItemsFromFile();
		
		ItemFactory itemFactory = ItemFactory.getInstance();
		
		
		Order order = new Order();
		order.addItem(itemFactory.createItem("Snack_124"));
		order.addItem(itemFactory.createItem("Snack_123"));
		
		order.addItem(itemFactory.createItem("Soft_213"));
		order.addItem(itemFactory.createItem("Soft_213"));
		order.addItem(itemFactory.createItem("Other_345"));
		order.addItem(itemFactory.createItem("Other_345"));
		order.addItem(itemFactory.createItem("Other_345"));
		order.addItem(itemFactory.createItem("Alcohol_412"));
		order.addItem(itemFactory.createItem("Alcohol_412"));
		order.addItem(itemFactory.createItem("Dish_213"));
		order.addItem(itemFactory.createItem("Dish_213"));
			
		float res = DiscountApplication.applyDiscount(price, order);

		assertEquals(decimalRoundValue(res), decimalRoundValue(expected_discount));
		
		Order order2 = new Order();
		assertEquals(0,DiscountApplication.applyDiscount(0, order2));
	}
	
	@Test
	void testApplyDiscount2() throws InvalidIDException {
		DiscountApplication.createDiscountList("discounts.csv");
		
		ItemFactory itemFactory = ItemFactory.getInstance();
		
		
		Order order = new Order();
		order.addItem(itemFactory.createItem("Snack_124"));
		order.addItem(itemFactory.createItem("Soft_213"));
		order.addItem(itemFactory.createItem("Other_345"));
		order.addItem(itemFactory.createItem("Alcohol_412"));
		order.addItem(itemFactory.createItem("Dish_213"));
		
		float price = order.getCost();
		float expected_discount = (float) (price - 1.0);
		
		float res = DiscountApplication.applyDiscount(price, order);
		assertEquals(decimalRoundValue(expected_discount),decimalRoundValue(res));
	}
	
	@Test
	void testApplyDiscount3() throws InvalidIDException {
		DiscountApplication.createDiscountList("test");
		
		ItemFactory itemFactory = ItemFactory.getInstance();
		
		
		Order order = new Order();
		order.addItem(itemFactory.createItem("Snack_124"));
		order.addItem(itemFactory.createItem("Soft_213"));
		order.addItem(itemFactory.createItem("Other_345"));
		order.addItem(itemFactory.createItem("Alcohol_412"));
		order.addItem(itemFactory.createItem("Dish_213"));
		
		float price = order.getCost();
		float expected_discount = (float) (price);
		
		float res = DiscountApplication.applyDiscount(price, order);
		assertEquals(decimalRoundValue(expected_discount),decimalRoundValue(res));
	}

}
