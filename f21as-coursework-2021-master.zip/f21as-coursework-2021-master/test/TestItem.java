package test; 

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import coffeeShop.ItemFactory;
import coffeeShop.InvalidIDException;
import coffeeShop.Item;
import coffeeShop.ItemCategory;

class TestItem {

	@Test
	void TestInvalidItem() {
		// all those items are invalid and throw InvalidIDException
		assertThrows(InvalidIDException.class, () -> new Item("invalidID", "", (float)0, ItemCategory.Dish));
		assertThrows(InvalidIDException.class, () -> new Item("invalid_123", "", (float)0, ItemCategory.Dish));
		assertThrows(InvalidIDException.class, () -> new Item("Dish_notANumber", "", (float)0, ItemCategory.Dish));
		assertThrows(InvalidIDException.class, () -> new Item("Dish_-555", "", (float)0, ItemCategory.Dish));
		assertThrows(InvalidIDException.class, () -> new Item("Dish_444", "", (float)0, ItemCategory.Soft));

		// try the creation of a valid Item
		try {
			Item item = new Item("Dish_999", "descritpion", (float) 12, ItemCategory.Dish);
			assertEquals(item.getId(), "Dish_999");
		} catch (InvalidIDException e) {
			fail();
		}
	}

	@Test
	void TestCopyItem() {
		// try the copy constructor of Item, and match the items attributes
		try {
			Item item = new Item("Other_999", "descritpion", (float) 12, ItemCategory.Other);
			Item itemCopy = new Item(item);
			assertEquals(item.getId(), itemCopy.getId());
			assertEquals(item.getName(), itemCopy.getName());
			assertEquals(item.getCost(), itemCopy.getCost());
			assertEquals(item.getCategory(), itemCopy.getCategory());
		} catch (Exception e) {
			fail();
		}
	}

}
