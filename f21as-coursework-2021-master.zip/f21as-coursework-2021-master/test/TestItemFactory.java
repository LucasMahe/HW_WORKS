package test;

import static org.junit.jupiter.api.Assertions.*;

import java.sql.Timestamp;
import java.util.List;

import org.junit.jupiter.api.Test;

import coffeeShop.ItemFactory;
import coffeeShop.InvalidIDException;
import coffeeShop.InvalidCostException;
import coffeeShop.Item;
import coffeeShop.ItemCategory;

class TestItemFactory {

	@Test
	void TestInvalidRegistration()
	{
		ItemFactory factory = ItemFactory.getInstance();

		// those registration must throw exceptions
		assertThrows(InvalidCostException.class, () -> factory.registerItem("Dish_123", "desc", null, ItemCategory.Dish));
		assertThrows(InvalidCostException.class, () -> factory.registerItem("Dish_123", "desc", (float)-12, ItemCategory.Dish));
		assertThrows(InvalidIDException.class, () -> factory.registerItem("Dish_INVALID", "desc", (float)12, ItemCategory.Dish));

		try {
			// cannot add twice an item with the same ID
			assertTrue(factory.registerItem("Dish_123", "sandwich", (float) 7, ItemCategory.Dish));
			assertFalse(factory.registerItem("Dish_123", "cookie", (float) 2, ItemCategory.Dish));
		} catch (Exception e) {
			fail();
		}
	}

	@Test
	void TestFactoryContent()
	{
		ItemFactory factory = ItemFactory.getInstance();

		try {
			// register items in the factory
			factory.registerItem("Alcohol_444", "sandwich", (float) 5, ItemCategory.Alcohol);
			factory.registerItem("Soft_456", "beer", (float) 4, ItemCategory.Soft);
			factory.registerItem("Other_789", "pen", (float) 1, ItemCategory.Other);

			// test the content in the factory
			assertNotNull(factory.createItem("Other_789"));
			assertThrows(InvalidIDException.class, () -> factory.createItem("Other_111"));

			List<String> ids = factory.getIDs();
			assertTrue(ids.contains("Alcohol_444"));
			assertTrue(ids.contains("Soft_456"));
			assertTrue(ids.contains("Other_789"));
		} catch (Exception e) {
			fail();
		}
	}

}
