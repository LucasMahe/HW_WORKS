package test;

import static org.junit.jupiter.api.Assertions.*;

import java.sql.Timestamp;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import coffeeShop.Customer;
import coffeeShop.DiscountApplication;
import coffeeShop.InvalidIDException;
import coffeeShop.Item;
import coffeeShop.Order;
import coffeeShop.ItemCategory;
import coffeeShop.ItemFactory;
import coffeeShop.ItemFileParser;


class TestCustomerOrder {

	@Test
	void TestCreateCustomer() {
		int id = 12345;
		Customer c1 = new Customer();
		Customer c2 = new Customer(id);

		assertNotEquals(c1.getId(), c2.getId());
		assertEquals(c2.getId(), id);
	}

	@Test
	void TestCreateCustomerOrder() {
		Customer c = new Customer();
		assertFalse(c.addItemCurrentOrder(null));
		assertFalse(c.removeItemCurrentOrder(null));

		try {
			Item item1 = new Item("Dish_999", "", (float) 12, ItemCategory.Dish);
			Item item2 = new Item("Other_998", "", (float) 4, ItemCategory.Other);

			assertTrue(c.addItemCurrentOrder(item1));
			assertTrue(c.removeItemCurrentOrder(item1));
			assertFalse(c.removeItemCurrentOrder(item2));
			assertTrue(c.addItemCurrentOrder(item2));

			assertEquals(c.getAllItems().size(), 0);
			c.saveOrder();
			assertEquals(c.getAllItems().size(), 1);
		} catch (InvalidIDException e) {
			fail();
		}
	}

	@Test
	void TestDiscountCustomerOrder() {
		Customer c = new Customer();

		DiscountApplication.createDiscountList("discounts.csv");
		ItemFileParser.registerItemsFromFile();

		ItemFactory itemFactory = ItemFactory.getInstance();
		float expectedCost = 0;

		try {
			expectedCost = itemFactory.createItem("Soft_213").getCost() * 2;

			c.addItemCurrentOrder(itemFactory.createItem("Soft_213"));
			c.addItemCurrentOrder(itemFactory.createItem("Soft_213"));
			c.addItemCurrentOrder(itemFactory.createItem("Soft_213"));
		} catch (InvalidIDException e) {
			fail();
		}

		Order order = c.getCurrentOrder();
		assertEquals(order.getDiscount(), expectedCost);
	}

}
