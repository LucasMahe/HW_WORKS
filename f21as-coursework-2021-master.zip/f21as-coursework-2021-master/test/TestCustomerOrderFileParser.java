package test;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.Test;

import coffeeShop.ItemFileParser;
import coffeeShop.CustomerOrderFileParser;
//import coffeeShop.CustomerOrderManager;
import coffeeShop.InvalidCostException;
import coffeeShop.InvalidIDException;
import coffeeShop.Item;
import coffeeShop.ItemFactory;
import coffeeShop.ItemCategory;


class TestCustomerOrderFileParser {
    @Test
    public void TestParseLine()
    {
        try {
			ItemFactory.getInstance().registerItem("Other_6", "paper", (float) 1.1, ItemCategory.Other);
		} catch (Exception e1) {
			fail();
		}
        // invalid line parsing
        assertFalse(CustomerOrderFileParser.registerCustomerOrderFromLine("2021-01-23 12:15:23, 2, Other_6, ERROR"));
        assertFalse(CustomerOrderFileParser.registerCustomerOrderFromLine("INVALID DATE, 2, Alcohol_213"));
        assertFalse(CustomerOrderFileParser.registerCustomerOrderFromLine("2021-01-23 12:15:23, INVALID NUMBER, Other_6"));
        assertFalse(CustomerOrderFileParser.registerCustomerOrderFromLine("2021-01-23 12:15:23, 2, INVALID ITEM"));
        assertFalse(CustomerOrderFileParser.registerCustomerOrderFromLine("2021-01-23 12:15:23, -2, Other_6"));

        // valid line parsing
        assertTrue(CustomerOrderFileParser.registerCustomerOrderFromLine("2021-01-23 12:15:23, 2, Other_6"));
        //assertTrue(CustomerOrderManager.getInstance().selectCustomerByIndex(2));
    }
}